package ru.job4j.io;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.StringJoiner;

public class CSVReader {

    private static final String FILE_PATH = "src/main/resources/data/file.csv";

    public void handle(ArgsName argsName) {
        var path = argsName.get("path");
        var delimiter = argsName.get("delimiter");
        var out = argsName.get("out");
        var filter = argsName.get("filter");
        // Сначала читаем файл
        var data = readData(path, delimiter);
        // Фильтруем дату
        var filteredData = dataFilter(data, filter, delimiter);
        filteredData.forEach(System.out::println);
    }

    private List<List<String>> readData(String path, String delimiter) {
        List<List<String>> data = new ArrayList<>();
        try (Scanner sc = new Scanner(new File(path))) {
            while (sc.hasNextLine()) {
                var lines = readLines(sc, delimiter);
                data.add(lines);
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return data;
    }

    private List<String> readLines(Scanner sc, String delimiter) {
        Scanner lineScanner = new Scanner(sc.nextLine()).useDelimiter(delimiter);
        List<String> lines = new ArrayList<>();
        while (lineScanner.hasNext()) {
            lines.add(lineScanner.next());
        }
        return lines;
    }

    private List<String> dataFilter(List<List<String>> data, String filter, String delimiter) {
        var header = data.get(0);
        var headerIndexes = extractHeaderIndexes(header, filter);
        var result = new ArrayList<String>();
        for (var list : data) {
            var element = getElement(headerIndexes, list, delimiter);
            result.add(element.toString());
        }
        return result;
    }

    private static List<Integer> extractHeaderIndexes(List<String> header, String filter) {
        List<Integer> columns = new ArrayList<>();
        for (var s : header) {
            if (filter.contains(s)) {
                columns.add(header.indexOf(s));
            }
        }
        return columns;
    }

    private StringJoiner getElement(List<Integer> indexes, List<String> list, String delimiter) {
        StringJoiner sj = new StringJoiner(delimiter);
        for (var index : indexes) {
            var el = list.get(index);
            sj.add(el);
        }
        return sj;
    }

    private void validateArguments(String[] args) {
        if (args.length != 4) {
            throw new IllegalArgumentException("Invalid arguments");
        }
        for (String s : args) {
            var strings = s.split("=");
            if (!strings[0].startsWith("-")) {
                throw new IllegalArgumentException("Wrong argument type! Arg key should be start with '-'");
            }
            switch (strings[0]) {
                case "-path":
                    var file = new File(strings[1]);
                    if (!file.exists()) {
                        throw new IllegalArgumentException("Root folder is not directory or not exist!");
                    }
                    break;
                case "-delimiter":
                case "-out":
                case "-filter":
                    if (strings[1] == null || strings[1].isEmpty()) {
                        throw new IllegalArgumentException("Wrong argument type! Arg value is null!");
                    }
                    break;
                default:
                    throw new IllegalArgumentException("Wrong argument type!");
            }
        }
    }

    public static void main(String[] args) throws Exception {
        var arg = new String[] {
                "-path=" + FILE_PATH,
                "-delimiter=",
                "-out=" + FILE_PATH,
                "-filter=name,age"};
        CSVReader reader = new CSVReader();
        reader.validateArguments(arg);
        var argsName = ArgsName.of(arg);
        reader.handle(argsName);
    }

}
