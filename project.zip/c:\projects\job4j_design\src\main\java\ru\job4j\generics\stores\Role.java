package ru.job4j.generics.stores;

public class Role extends Base {

    public Role(String id) {
        super(id);
    }

    @Override
    public String getId() {
        return super.getId();
    }

}
